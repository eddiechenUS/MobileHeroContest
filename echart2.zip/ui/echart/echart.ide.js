TW.IDE.Widgets.echart = function () {
    this.widgetIconUrl = function() {
        return "../Common/extensions/echart/ui/echart/default_widget_icon.ide.png";
    };

    this.widgetProperties = function () {
        return {
            name : "EchartWidget",
            description : "A simple Echart Widget creation.",
            category : ["Common"],
            properties : {
                DisplayData: {
                    baseType: "STRING",
                    //defaultValue: "Hello, Awesome User!",
                    isBindingTarget: true
                },
				Width : {
                    description: "Width",
                    baseType: 'NUMBER',
                    defaultValue: 800
                },
                Height: {
                    description: "Height",
                    baseType: 'NUMBER',
                    defaultValue: 600
                },GetFirstPoint: {
                    baseType: "STRING",
                    //defaultValue: "Hello, Awesome User!",
                    isBindingSource: true
                },GetOtherPoint: {
                    baseType: "STRING",
                    //defaultValue: "Hello, Awesome User!",
                    isBindingSource: true
                }
            } 
        }
    };

    this.renderHtml = function () {
        /*
		var mytext = this.getProperty('EchartWidget Property');

        var config = {
            text: mytext
        }
		
        var widgetTemplate = _.template(
            '<div class="widget-content widget-simplewidget widget-echart">' +
            '<span class="DisplayData"><%- text %></span>' +
            '</div>'
        );

        return widgetTemplate(config);
		*/
		
		var wedgetID="A_"+this.jqElementId;
		console.log("afterRender-->"+wedgetID);
		var width = this.getProperty("Width");
		var height = this.getProperty("Height");
		//var widgetTemplate= '<div class="widget-content widget-simplewidget widget-echart"> <div id="echartWidget"  style="width: '+ width +'px;height:'+ height +'px;"></div></div>';
		var widgetTemplate= '<div class="widget-content widget-simplewidget widget-echart"> <div id="'+wedgetID+'"  style="width: '+ width +'px;height:'+ height +'px;"></div></div>';
		
        
        //return widgetTemplate(config);
		return widgetTemplate;
    };

    this.afterSetProperty = function (name, value) {
        return true;
    };
};