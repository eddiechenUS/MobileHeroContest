TW.Runtime.Widgets.echart = function () {
    //var valueElem;
	var myChart;

    this.renderHtml = function () {
        /*
		var mytext = this.getProperty('EchartWidget Property');

        var config = {
            text: mytext
        }

		
        var widgetTemplate = _.template(
            '<div class="widget-content widget-simplewidget widget-echart">' +
            '<span class="DisplayData"><%- text %></span>' +
            '</div>'
        );
		return widgetTemplate(config);
		*/
		var wedgetID="A_"+this.jqElementId;
		console.log("renderHtml-->"+wedgetID);
		var width = this.getProperty("Width");
		var height = this.getProperty("Height");
		//var widgetTemplate= '<div class="widget-content widget-simplewidget widget-echart"> <div id="echartWidget"  style="width: '+ width +'px;height:'+ height +'px;"></div></div>';
		var widgetTemplate= '<div class="widget-content widget-simplewidget widget-echart"> <div id="'+wedgetID+'"  style="width: '+ width +'px;height:'+ height +'px;"></div></div>';
		
        
		return widgetTemplate;
    };

    this.afterRender = function () {
        $("body").append('<script type="text/javascript" src="../Common/extensions/echart/ui/echart/echarts.min.js"></script>');
		var wedgetID="A_"+this.jqElementId;
		console.log("afterRender-->"+wedgetID);
		//myChart = echarts.init(document.getElementById('echartWidget'));
		myChart = echarts.init(document.getElementById(wedgetID));
		var str='{"xAxis":{"type":"category","data":[]},"yAxis":{"type":"value"},"series":[{"data":[],"type":"line","smooth":true}]}';
		myChart.setOption(JSON.parse(str));
		myChart.on('click', function (params) {
			console.log(params.data);
		});
		
		//valueElem = this.jqElement.find(".DisplayData");
        //valueElem.text(this.getProperty("DisplayData"));
		
    };

    this.updateProperty = function (updatePropertyInfo) {
        if (updatePropertyInfo.TargetProperty === "DisplayData") {
            //valueElem.text(updatePropertyInfo.SinglePropertyValue);
            this.setProperty("DisplayData", updatePropertyInfo.SinglePropertyValue);
			//console.log(updatePropertyInfo.SinglePropertyValue);
			var sss=updatePropertyInfo.SinglePropertyValue;
			//var wedgetID=this.jqElementId;
			//console.log("updateProperty-->"+wedgetID);
			//myChart = echarts.init(document.getElementById(wedgetID));
			var sPtyFirst = this ;
			var sPtyOther = this ;
			this.setProperty("GetFirstPoint","GetFirstPoint");
			this.setProperty("GetOtherPoint","GetOtherPoint");
			myChart.clear();
			myChart.setOption(JSON.parse(sss), true);
			var pintA_data = [];
			var pintB_data = [];
			var countNum = 1 ;
			myChart.on('click', function (params) {
				var tmPoint = params.data; 
				  if(countNum == 1){
					  pintA_data = [];
					  pintA_data.push(tmPoint);
						myChart.setOption({
							series: [{
								id: 'pointFirst',
								data: pintA_data,
							}]
						});
					countNum = 2;
					sPtyFirst.setProperty("GetFirstPoint",pintA_data.toString())
				  }else{
					  pintB_data = [];
					  pintB_data.push(tmPoint);
					  myChart.setOption({
						series: [{
							id: 'pointOther',
							data: pintB_data,
						}]
						
					});
					countNum = 1;
					sPtyOther.setProperty("GetOtherPoint",pintB_data.toString())
				  }
			});
        }
    }; 
};